#!/usr/bin/env python3
"""Conditional coherent axis-contact instrument and exact no-revival witnesses.

Python 3.10+, NumPy and SciPy. All structural gates use integers or Q(sqrt(5)).
Pulse tables are separately labelled floating-point diagnostics. The dynamical
choice exp(-i*t*A) and the amplitude/readout interpretation are NEW assumptions,
not a derivation of quantum dynamics or Born probabilities from path counts.
"""
from __future__ import annotations
import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
from pathlib import Path
import argparse, hashlib, json, subprocess, sys, tempfile, zipfile
from fractions import Fraction
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import expm_multiply
from exact_field import Field, scalar
ROOT=Path(__file__).resolve().parent
CHECKS={}
TOL=5e-11
PULSES=[0.0,0.1,0.25,0.5,1.0,2.0,3.0,4.0]
def load(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(name,obj): (ROOT/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n',encoding='utf-8')
def ck(name,value):
    if name in CHECKS: raise AssertionError('duplicate check '+name)
    CHECKS[name]=bool(value)
    if not CHECKS[name]: raise AssertionError(name)
def extract(src,dst):
    with zipfile.ZipFile(src) as z:
        for m in z.infolist():
            if not (dst/m.filename).resolve().is_relative_to(dst.resolve()):
                raise ValueError('unsafe archive member')
        z.extractall(dst)
def comp(g,h): return tuple(g[h[i]] for i in range(len(g)))
def inv(g):
    q=[0]*len(g)
    for i,j in enumerate(g): q[j]=i
    return tuple(q)
def powers(g):
    out=[tuple(range(len(g)))]
    for _ in range(4): out.append(comp(g,out[-1]))
    return frozenset(out)
def field_num(x): return (x.a.astype(float)+np.sqrt(5)*x.b.astype(float))/x.d
def char(x,g):
    rr=np.arange(len(g));return Field([[sum(int(v) for v in x.a[rr,g])]],[[sum(int(v) for v in x.b[rr,g])]],x.d)
def source_gram(P,a,b):
    # W0 = FC|V/sqrt(2*(14+6sqrt(5))); reciprocal scale=(7-3sqrt(5))/16.
    return (P@Field(a.T@b)@P).scale(7,-3,16)
def coeff_field(rec):return scalar(*rec)
def finite_float(x):
    x=float(np.real(x))
    if not np.isfinite(x): raise AssertionError('non-finite number')
    return float(format(x,'.14g'))
def maxabs(a):return float(np.max(np.abs(a)))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--skip-upstream-replay',action='store_true',help='development only; recorded as not replayed')
    args=parser.parse_args()
    source=load(ROOT/'SOURCE_RECEIPTS.json');arc=ROOT/source['archive']
    print('STAGE: source checks and upstream replay',flush=True)
    ck('source_archive_sha256',sha(arc)==source['sha256'])
    ck('source_archive_bytes',arc.stat().st_size==source['bytes'])
    with tempfile.TemporaryDirectory(prefix='coherent_axis_') as td:
        td=Path(td);extract(arc,td);old=td/'native_axis_contact_pointer_audit'
        before={p.name:sha(p) for p in old.glob('*.json')}
        if not args.skip_upstream_replay:
            run=subprocess.run([sys.executable,str(old/'verify.py')],cwd=old,text=True,capture_output=True,timeout=240)
            if run.returncode: print(run.stdout,run.stderr,file=sys.stderr)
            ck('upstream_replay_exit_zero',run.returncode==0)
            ck('upstream_JSON_byte_identical',before=={p.name:sha(p) for p in old.glob('*.json')})
        report=load(old/'REPORT.json')
        ck('upstream_10048_checks',report['check_count']==10048 and report['audit_pass'])
        refs=load(old/'AXIS_REFERENCES.json');auts=load(old/'NATIVE_AUTOMORPHISMS.json')
        extract(old/'upstream/native_reference_contact_gate.zip',td)
        ref=td/'native_reference_contact_gate'
        extract(ref/'upstream/native_analyzer_return_bridge.zip',td)
        bridge=td/'native_analyzer_return_bridge'
        pr=load(bridge/'EXACT_PROJECTORS.json');inter=load(bridge/'INTERFACE_ROWS.json')
        extract(bridge/'upstream/clean_history_multiplicity_audit.zip',td)
        base=td/'clean_history_multiplicity_audit'
        states=load(base/'BALANCED_STATES.json');ports=load(base/'CLEAN_PORTS.json')['pairs'];moves=load(base/'BALANCED_MOVES.json')['rows']
    n=len(states);clean=np.array([bool(s['is_clean']) for s in states]);nc=~clean
    regions=[tuple(s['vertices']) for s in states];index={tuple(sorted(v)):i for i,v in enumerate(regions)}
    ck('1980_region_states',n==1980);ck('480_clean_states',int(clean.sum())==480);ck('240_clean_pairs',len(ports)==240)
    def mat(rows):
        u,v=zip(*rows)
        return sparse.csr_matrix((np.ones(len(u),dtype=np.int64),(u,v)),shape=(n,n))
    def symmetric(M):return (M-M.T).nnz==0
    J=mat([(u,v) for u,v,t in moves if t==3 and clean[u]])
    H=mat([(u,v) for u,v,t in moves if t==3 and not clean[u]])
    ck('J_symmetric',symmetric(J));ck('H_symmetric',symmetric(H))
    C=np.zeros((240,60),dtype=np.int64);F=np.zeros((n,240),dtype=np.int64)
    for p,row in enumerate(ports):
        u,v=row['pair'];F[u,p]=1;F[v,p]=-1
        for x,c in inter[p]['region_difference']:C[p,x]=c
    X=F@C;P=Field.from_record(pr['leading']);Pn=field_num(P)
    ck('source_projector', (P@P).equal(P) and P.trace().equal(scalar(6)))
    ck('source_isometry_exact',source_gram(P,X,X).equal(P))
    ck('clean_swap_on_source',np.array_equal(J@X,-X))
    evals,evects=np.linalg.eigh(Pn);V=evects[:,evals>.5]
    W=X@V/np.sqrt(2*(14+6*np.sqrt(5)))
    ck('numerical_source_isometry',maxabs(W.T@W-np.eye(6))<TOL)
    region_cache={}
    def region_action(g):
        g=tuple(g)
        if g not in region_cache:
            region_cache[g]=np.array([index[tuple(sorted(g[x] for x in vv))] for vv in regions],dtype=np.int64)
        return region_cache[g]
    symmetry_rows=[];exact_rows=[];pulse_rows=[];witness_rows=[];max_numeric_error=0.0
    witness_inputs=[load(ROOT/'inputs'/('witness_'+label+'.json')) for label in ('two','minus_three','sqrt_three')]
    origin=set(refs[0]['reference_vertices'])
    for axis,row in enumerate(refs):
        print(f'STAGE: exact and numerical axis {axis+1}/6',flush=True)
        R=set(row['reference_vertices']);sub=powers(tuple(row['C5_generator60']))
        normal=[g for g in auts if comp(g,comp(tuple(row['C5_generator60']),inv(g))) in sub]
        ck(f'normalizer_order80:{axis}',len(normal)==80)
        Pi=Field.from_record(pr['axes']['B_plus3'][axis])+Field.from_record(pr['axes']['B_minus3'][axis]);Q=P-Pi
        ck(f'axis_rank2_projector:{axis}',(Pi@Pi).equal(Pi) and Pi.trace().equal(scalar(2)))
        ck(f'plane_rank4_projector:{axis}',(Q@Q).equal(Q) and Q.trace().equal(scalar(4)))
        inner={name:scalar(0) for name in ('axis','plane','cross','full')}
        B=mat(row['directed_d4_contact_edges']);K=H+B;Gp=J+K;Gm=-J+K
        degree=np.asarray(Gp.sum(axis=1)).ravel();Deg=sparse.diags(degree,format='csr',dtype=np.float64)
        ck(f'5600_contact_edges:{axis}',B.nnz==5600)
        ck(f'8960_directed_ordinary_edges:{axis}',Gp.nnz==8960)
        ck(f'parity_generators_symmetric:{axis}',symmetric(Gp) and symmetric(Gm))
        ck(f'no_contact_edges_edited:{axis}',all((set(regions[u])^set(regions[v]))&R for u,v in row['directed_d4_contact_edges']))
        for gi,g in enumerate(normal):
            c=char(Pi,g);d=char(Q,g)
            inner['axis']=inner['axis']+c@c;inner['plane']=inner['plane']+d@d
            inner['cross']=inner['cross']+c@d;inner['full']=inner['full']+(c+d)@(c+d)
            ck(f'axis_projector_invariant:{axis}:{gi}',Pi.transport(g).equal(Pi))
            ck(f'source_projector_invariant:{axis}:{gi}',P.transport(g).equal(P))
            perm=region_action(g)
            ck(f'source_incidence_equivariance:{axis}:{gi}',np.array_equal(X[np.ix_(perm,g)],X))
            ck(f'clean_readout_equivariance:{axis}:{gi}',np.array_equal(clean[perm],clean))
            ck(f'full_contact_covariance:{axis}:{gi}',(Gp[perm][:,perm]-Gp).nnz==0)
            ck(f'primary_clean_write_covariance:{axis}:{gi}',(J[perm][:,perm]-J).nnz==0)
        for name,val in [('axis',1),('plane',1),('cross',0),('full',2)]:
            inner[name]=inner[name].scale(1,0,80);ck(f'exact_character_inner_product_{name}:{axis}',inner[name].equal(scalar(val)))
        symmetry_rows.append({'axis':axis,'normalizer_order':80,'source_axis_rank':2,'source_plane_rank':4,
          'complex_irreducibility_character_inner_products':{k:v.record() for k,v in inner.items()}})
        # Exact low-order pointer effects from FULL lifted microscopic powers.
        y0=X.copy();y1=np.zeros_like(X);ys=[]
        for step in range(1,4):
            y0,y1=K@y0+J@y1,K@y1+J@y0
            ys.append(y1.copy())
        e2=source_gram(P,ys[0],ys[0]);e4=(source_gram(P,ys[1],ys[1]).scale(1,0,4)
           -(source_gram(P,ys[0],ys[2])+source_gram(P,ys[2],ys[0])).scale(1,0,6))
        L2=source_gram(P,B@X,B@X)
        ck(f'exact_second_order_effect_identity:{axis}',e2.equal(P))
        ck(f'exact_fourth_order_effect:{axis}',e4.equal(-P.scale(1,0,3)-L2.scale(5,0,12)))
        expected=Pi.scale(-63,1,24)+Q.scale(-79,1,32)
        ck(f'exact_axis_plane_fourth_order_coefficients:{axis}',e4.equal(expected))
        exact_rows.append({'axis':axis,'pointer1_second_order':'I_V',
          'pointer1_fourth_order_axis':[-63,1,24],'pointer1_fourth_order_plane':[-79,1,32],
          'axis_minus_plane_fourth_order':[-15,1,96]})
        # Small exact spectral witnesses; candidates discovered numerically but
        # eigenvector identities and overlaps are checked using integers/fields.
        g=next(g for g in auts if {g[x] for x in origin}==R);perm=region_action(g)
        for wi in witness_inputs:
            v=np.zeros(n,dtype=np.int64)
            for ix,value in wi['vector_sparse']:v[perm[ix]]=value
            if wi['eigenvalue'] is not None:
                lam=wi['eigenvalue'];ok=np.array_equal(Gp@v,lam*v)
            else:ok=np.array_equal(Gp@(Gp@v),3*v)
            ck(f'exact_spectral_witness_{wi["label"]}:{axis}',ok)
            overlap=Field((v@X)[None,:])@Q
            ck(f'nonzero_plane_overlap_{wi["label"]}:{axis}',not overlap.zero())
            witness_rows.append({'axis':axis,'label':wi['label'],'polynomial_coefficients':wi['polynomial_coefficients'],
              'support_size':int(np.count_nonzero(v)),'exact_plane_overlap':overlap.record()})
        piv=V.T@field_num(Pi)@V;ip=np.eye(6)-piv
        for model,plus,minus in [('adjacency',Gp,Gm),('laplacian_control',Deg-Gp,Deg-Gm)]:
            for t in PULSES:
                if t==0:vp=vm=W.astype(complex)
                else:
                    vp=expm_multiply((-1j*t)*plus,W)
                    vm=expm_multiply((-1j*t)*minus,W)
                outs=[(vp+vm)/2,(vp-vm)/2]
                E=[y.conj().T@y for y in outs];normerr=maxabs(E[0]+E[1]-np.eye(6));max_numeric_error=max(max_numeric_error,normerr)
                ck(f'numerical_completeness:{model}:{axis}:{t}',normerr<TOL)
                data={'axis':axis,'model':model,'dimensionless_pulse':t,'effects':{}}
                allfour=[]
                for b in (0,1):
                    for name,mask in [('all',np.ones(n,dtype=bool)),('clean',clean),('nonclean',nc)]:
                        yy=outs[b][mask];eff=yy.conj().T@yy
                        aa=float(np.trace(piv@eff).real/2);bb=float(np.trace(ip@eff).real/4)
                        err=maxabs(eff-aa*piv-bb*ip);max_numeric_error=max(max_numeric_error,err)
                        ck(f'numerical_effect_partition:{model}:{axis}:{t}:{b}:{name}',err<TOL)
                        ck(f'numerical_effect_bounds:{model}:{axis}:{t}:{b}:{name}',min(aa,bb)>-TOL and max(aa,bb)<1+TOL)
                        data['effects'][f'{name}_pointer_{b}']={'axis':finite_float(aa),'plane':finite_float(bb)}
                        if name!='all':allfour.append(eff)
                ck(f'numerical_four_outcomes_complete:{model}:{axis}:{t}',maxabs(sum(allfour)-np.eye(6))<TOL)
                pulse_rows.append(data)
                if axis==0 and model=='adjacency' and t==2.0:
                    lifted=sparse.bmat([[K,J],[J,K]],format='csr')
                    ck('pointer_lift_3960_states_17920_directed_edges',lifted.shape==(3960,3960) and lifted.nnz==17920)
                    initial=np.vstack([W,np.zeros_like(W)])
                    direct=expm_multiply(-2j*lifted,initial)
                    ck('numerical_full3960_vs_parity_blocks',maxabs(direct-np.vstack(outs))<TOL)
    print('STAGE: final covariance and export',flush=True)
    # No fitted pulse or favorable axis is chosen. Match all six against axis 0.
    for row in pulse_rows:
        baseline=next(x for x in pulse_rows if x['axis']==0 and x['model']==row['model'] and x['dimensionless_pulse']==row['dimensionless_pulse'])
        ck(f'numerical_axis_covariance:{row["model"]}:{row["axis"]}:{row["dimensionless_pulse"]}',
           max(abs(row['effects'][k][s]-baseline['effects'][k][s]) for k in row['effects'] for s in ('axis','plane'))<TOL)
    ck('irrational_revival_obstruction_premises_checked',len(witness_rows)==18)
    record={'audit_pass':all(CHECKS.values()),'check_count':len(CHECKS),'failed_check_count':sum(not v for v in CHECKS.values()),
      'verdict':'conditional_normalized_axis_sensitive_instrument_and_exact_constant_adjacency_no_revival',
      'upstream_replayed':not args.skip_upstream_replay,'upstream_check_count':10048,
      'point_domain':{'region_states':1980,'pointer_states':2,'complete_states':3960,'directed_lifted_edges_per_axis':17920},
      'exact_results':{'normalizer_source_complex_commutant_dimension':2,'irreducible_source_dimensions':[2,4],
        'all_pulse_effect_form':'a_b(t) Pi_i + b_b(t) (I-Pi_i)',
        'pointer1_short_pulse_axis':'t^2-(63-sqrt(5))*t^4/24+O(t^6)',
        'pointer1_short_pulse_plane':'t^2-(79-sqrt(5))*t^4/32+O(t^6)',
        'pointer1_axis_minus_plane':'-(15-sqrt(5))*t^4/96+O(t^6)',
        'constant_adjacency_plane_supported_eigenvalues':['2','-3','sqrt(3)','-sqrt(3)'],
        'exact_same_code_nondemolition_write_at_nonzero_adjacency_pulse':False,
        'no_go_scope':'constant unweighted lifted-adjacency evolution; fixed W0 code and primary-clean pointer; target source restored up to phase'},
      'numerical_diagnostics':{'tolerance':TOL,'maximum_observed_error':finite_float(max_numeric_error),'predeclared_pulses':PULSES,
        'axis_count':6,'model_count':2,'source_band_dimension':6,'optimized_for_performance_or_Bell_score':False},
      'boundaries':{'coherent_dynamics_is_added_hypothesis':True,'amplitude_source_preparation_not_derived':True,
        'coordinate_pointer_readout_is_declared_model_operation':True,'Born_frequency_law_derived':False,
        'physical_time_or_action_calibration':False,'ideal_instrument_constructed':False,'approximate_or_pulsed_controls_ruled_out':False,
        'laplacian_control_subject_to_adjacency_no_go':False,'source_not_compressed_between_steps':True,
        'all_nonclean_outputs_retained':True,'conditioning_on_completion_used':False,'microscopic_latch_or_autonomous_stop_derived':False,
        'physical_Bell_experiment_or_unification_claim':False,'repository_or_library_mutated':False}}
    dump('REPORT.json',record);dump('CHECKS.json',CHECKS)
    dump('EXACT_SYMMETRY.json',symmetry_rows);dump('EXACT_SHORT_PULSE.json',exact_rows)
    dump('EXACT_NO_REVIVAL_WITNESSES.json',witness_rows)
    dump('NUMERICAL_PULSES.json',{'interpretation':'Conditional squared-norm response under declared coherent evolution; not native frequencies',
          'arithmetic':'floating point, checked at 5e-11; tables rounded to 14 significant digits', 'rows':pulse_rows})
    print(json.dumps(record,indent=2,sort_keys=True))
if __name__=='__main__':main()
