"""Small exact matrix arithmetic in Q(sqrt(5)), using reduced common denominators."""
from __future__ import annotations
from functools import reduce
from math import gcd
import numpy as np

class Field:
    def __init__(self,a,b=None,d=1):
        a=np.asarray(a,dtype=object)
        b=np.zeros_like(a) if b is None else np.asarray(b,dtype=object)
        if a.shape!=b.shape or d==0: raise ValueError('field shape/denominator')
        d=int(d)
        if d<0:a=-a;b=-b;d=-d
        common=gcd(d,reduce(gcd,(abs(int(x)) for x in a.flat),0))
        common=gcd(common,reduce(gcd,(abs(int(x)) for x in b.flat),0))
        if common>1:a=a//common;b=b//common;d//=common
        limit=max(max((abs(int(x)) for x in a.flat),default=0),max((abs(int(x)) for x in b.flat),default=0))
        dtype=np.int64 if limit<2**62 else object
        self.a=np.asarray(a,dtype=dtype); self.b=np.asarray(b,dtype=dtype);self.d=d
    def __add__(self,o):
        if not isinstance(o,Field):o=Field(o)
        return Field(self.a.astype(object)*o.d+o.a.astype(object)*self.d,
                     self.b.astype(object)*o.d+o.b.astype(object)*self.d,self.d*o.d)
    def __neg__(self):return Field(-self.a,-self.b,self.d)
    def __sub__(self,o):return self+-o
    def scale(self,a=1,b=0,d=1):
        return Field(int(a)*self.a.astype(object)+5*int(b)*self.b.astype(object),
                     int(b)*self.a.astype(object)+int(a)*self.b.astype(object),self.d*int(d))
    def __matmul__(self,o):
        if not isinstance(o,Field):o=Field(o)
        lim1=max(np.max(np.abs(self.a)),np.max(np.abs(self.b)))
        lim2=max(np.max(np.abs(o.a)),np.max(np.abs(o.b)))
        dtype=np.int64 if 6*int(lim1)*int(lim2)*self.a.shape[-1]<2**62 else object
        a,b,c,e=(np.asarray(x,dtype=dtype) for x in [self.a,self.b,o.a,o.b])
        return Field(a@c+5*(b@e),a@e+b@c,self.d*o.d)
    def zero(self):return not np.any(self.a) and not np.any(self.b)
    def equal(self,o):return (self-o).zero()
    def trace(self):return Field([[sum(int(x) for x in np.diag(self.a))]],[[sum(int(x) for x in np.diag(self.b))]],self.d)
    def transport(self,g):
        inv=np.argsort(g); idx=np.ix_(inv,inv)
        return Field(self.a[idx],self.b[idx],self.d)
    def record(self):return {'rational_numerator':self.a.tolist(),'sqrt5_numerator':self.b.tolist(),'denominator':self.d}
    @classmethod
    def from_record(cls,r):return cls(r['rational_numerator'],r['sqrt5_numerator'],r['denominator'])

def scalar(a,b=0,d=1):return Field([[a]],[[b]],d)

def power_trace_from_roots(roots,k):
    out=scalar(0)
    for a,b,d in roots:
        x=scalar(1);v=scalar(a,b,d)
        for _ in range(k):x=x@v
        out=out+x
    return out
