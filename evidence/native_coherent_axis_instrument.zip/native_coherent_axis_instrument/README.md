# Coherent axis contact: normalized pointer instrument and a constant-pulse obstruction

17 September 2026

## Result and status

This continuation puts the existing axis-contact graph and primary-clean receipt tracker inside an explicitly declared coherent evolution model. It obtains a normalized, analyzer-sensitive generalized pointer instrument without discarding any nonclean output. It also proves that a constant unweighted adjacency pulse cannot realize the proposed exact nondemolition controlled write on the original source code at any nonzero duration.

There are three evidence levels. The reference patterns, contact edges, region embedding, and pointer cochain are inherited finite constructions. The choice of complex amplitudes, a coherent initial source, `exp(-i*t*A)` evolution, and pointer readout is an added model hypothesis. The ensuing completeness, all-duration effect partition, short-pulse coefficients, and no-revival theorem are mathematical consequences of that hypothesis and the finite inputs. Numerical pulse tables are illustrative, not proofs of the all-duration claims or measurements of physical frequencies.

No physical time scale, Hamiltonian selection principle, Born-frequency derivation, detector latch, autonomous stopping rule, or Bell experiment is established. This is an explicit conditional completion rather than a reinterpretation of raw path counts as probabilities.

The delivered run has **4,457 passing checks and zero failures**: 3,015 exact structural/provenance checks and 1,442 separately labelled numerical checks. Both complete default runs replay the upstream 10,048-check packet; all six generated JSON outputs are byte-identical between the two new runs.

## 1. Frozen inputs

The sole upstream archive is `native_axis_contact_pointer_audit.zip`. Its bytes and SHA-256 hash are recorded in SOURCE_RECEIPTS.json. Its verifier is replayed by default, including the nested preceding audits, with all of its JSON outputs compared byte-for-byte. No historical producer or user repository is changed.

The microscopic region domain has 1,980 states. Its clean boundary has 480 states and 240 clean pairs. The source band V has dimension six and is the native `1+sqrt(5)` band. Its two native deck-character sectors each have dimension three.

For every one of six order-five subgroups, the unique smaller orbit of its 80-element normalizer supplies a 20-vertex reference pattern. The inherited contact rule enables an original d4 edge S--T when at least one vertex in that pattern changes region membership. It keeps 5,600 directed d4 edges. All original d3 moves remain.

The independent two-state pointer toggles ONLY on primary-clean d3 edges. It is not the clean/nonclean excursion coordinate and is not the all-d3 step-parity tracker.

Let J_C be adjacency on the primary-clean pairs, H_N adjacency on nonclean d3 edges, and B_i the full symmetric d4 contact adjacency. J_C is zero outside the clean boundary. H_N is zero on it. The pointer-ready convention is |0>. The complete point domain has 3,960 states and 17,920 directed lifted edges per setting.

The source embedding is the inherited isometry

    W0 = F C|V / sqrt(2*(14+6sqrt(5))).

F contains the signed clean-pair contrasts and C contains their region-incidence differences. Source functions in this code are not point preparations of an individual clean state. A physical preparation of their coherent amplitudes is a separate resource.

## 2. Declare a coherent model before evaluating outcomes

Use complex vector functions on the entire pointer-extended region domain. In pointer-value order, define

    K_i = H_N + B_i,
    G_i = [[K_i, J_C], [J_C, K_i]].

The off-diagonal blocks implement the chosen primary-clean pointer write. All matrices here come from the frozen microscopic edge construction. G_i is real symmetric, so

    U_i(t) = exp(-i*t*G_i)

is unitary for every real t. The parameter t is dimensionless integrated coupling, NOT a claimed physical duration or Thalean winding.

This exponential weights walks by (-i*t)^n/n!. That coherent composition rule is added; it is not determined by merely counting the walks. In particular it is not the state-dependent normalization of a raw power G_i^n.

A comparison model uses the combinatorial Laplacian

    L_i = degree_i - G_i.

The same degree diagonal is used in both pointer sectors, as required by the actual lifted graph. Adjacency and Laplacian are distinct model choices. Neither is promoted to a uniquely derived physical generator.

## 3. Pointer-parity reduction retains the full region domain

Diagonalize the pointer swap, not the microscopic source:

    G_i,+ = K_i + J_C,
    G_i,- = K_i - J_C.

Each block still acts on all 1,980 region states. For the ready embedding W0 tensor |0>, define

    M_i,0(t) = [exp(-i*t*G_i,+) + exp(-i*t*G_i,-)] W0 / 2,
    M_i,1(t) = [exp(-i*t*G_i,+) - exp(-i*t*G_i,-)] W0 / 2.

These map the six-dimensional input into the complete region output space. No source projection is applied between steps or before evaluating the full pointer output. Direct evolution on all 3,960 states is also compared numerically with this exact parity-block formula.

Set E_i,b=M_i,b^dagger M_i,b. Unitarity and W0's isometry give

    E_i,0 >= 0,  E_i,1 >= 0,
    E_i,0 + E_i,1 = I_V.

Thus the maps rho -> M_i,b rho M_i,b^dagger are a normalized mathematical instrument under the declared amplitude/readout interpretation. No scalar renormalization is required. The post-interaction state resides on the full region domain, not necessarily in W0(V).

## 4. Exact analyzer partition for EVERY pulse duration

The full native normalizer N_i preserves the chosen contact graph, the clean-edge pointer write, and the source embedding. The verifier checks those actions on the actual region states and source incidence matrix.

Let Pi_i be the paired rank-two analyzer-axis projector, and Q_i=I_V-Pi_i the rank-four complementary-plane projector. Exact character sums over all 80 normalizer elements give

    <chi_axis,chi_axis> = 1,
    <chi_plane,chi_plane> = 1,
    <chi_axis,chi_plane> = 0,
    <chi_V,chi_V> = 2.

Thus the complexified source representation consists of two inequivalent irreducibles, of dimensions two and four. Its complex commutant is exactly span{Pi_i,Q_i}.

Every pointer effect commutes with this normalizer, because preparation, evolution, and the pointer readout intertwine the native action. Therefore, for ALL real t,

    E_i,b(t) = a_b(t) Pi_i + b_b(t) Q_i,
    a_0+a_1 = b_0+b_1 = 1,
    0 <= a_b,b_b <= 1.

On either individual three-dimensional character sector this is the original rank-one analyzer line and its complementary plane. The same scalar response functions apply to all six settings by native covariance.

The conclusion is not inferred from a finite pulse scan. It follows from the exact representation calculation and the symmetry of the full microscopic generator.

Using the FULL normalizer matters. C5 symmetry alone would not force a general complex Hermitian operator to be scalar on the complexified real rotation plane: opposite rotation characters can carry different coefficients. The character calculation here supplies the stronger symmetry needed for the all-duration assertion.

## 5. Exact short-pulse response

Compute the first three powers of the full lifted microscopic generator acting on the unnormalized region-incidence source. No amplitude-dependent contact or desired answer enters those powers.

The pointer-1 effect has expansion

    E_i,1(t) = t^2 I_V - t^4 [I_V/3 + 5 L2_i/12] + O(t^6),

where the inherited two-step return compression is

    L2_i = [(55-sqrt(5))/10] Pi_i
           + [(205-3sqrt(5))/40] Q_i.

Consequently

    a_1(t) = t^2 - [(63-sqrt(5))/24] t^4 + O(t^6),
    b_1(t) = t^2 - [(79-sqrt(5))/32] t^4 + O(t^6),

and

    a_1(t)-b_1(t) = -[(15-sqrt(5))/96] t^4 + O(t^6).

This is nonzero for sufficiently small nonzero t. The conditional instrument is therefore genuinely analyzer-sensitive, not just normalized noise. It is unsharp: in that small-pulse regime, both source sectors contribute to both pointer values.

The first pointer write contribution is source-independent at order t^2. The reference-conditioned excursion enters the pointer distinction at order t^4. The nonclean-region effect itself begins as t^2 L2_i, so the excursion occupancy can reveal the axis/plane distinction before the pointer value alone does.

Because the effects are scalar on the two irreducibles and the generator is real, their coefficients are even functions of t. The omitted terms in the displayed expansion begin at order six.

## 6. Clean completion is a separate output, not a postselection shortcut

Let P_C select all 480 clean region states and P_N its complement. Retain the four maps

    M_C,b = P_C M_i,b,
    M_N,b = P_N M_i,b.

They obey

    sum over b [M_C,b^dagger M_C,b + M_N,b^dagger M_N,b] = I_V.

A clean-boundary readout may therefore report C0, C1, and an unfinished label for the aggregate nonclean output. The calculation does NOT divide by the clean-completion probability. Even a clean output need not lie in the original six-dimensional source code.

The pulse table reports all-region pointer effects and their clean/nonclean pieces. For example, at t=2 in the adjacency model, pointer-1 squared norms are approximately 0.5303456435 on the axis and 0.6033071148 on the plane. The corresponding clean-pointer-1 portions are only approximately 0.1060406250 and 0.1310217786. Treating the all-region numbers as completed, restored detector outcomes would conceal substantial nonclean output.

These are conditional squared-norm values. Their physical interpretation as observed frequencies would invoke an additional quantum measurement rule.

## 7. Exact obstruction to the ideal constant-adjacency pulse

The original desired instrument restores the source code and writes a fixed pointer value for each analyzer eigenspace:

    psi_axis tensor |0> -> psi_axis tensor |0>,
    psi_plane tensor |0> -> psi_plane tensor |1>,

allowing irrelevant overall branch phases. This is stronger than the unsharp instrument above.

The new certificate supplies three small integer vectors for setting zero. Each has support on 14 region states. They obey

    G_+ v_2 = 2 v_2,
    G_+ v_-3 = -3 v_-3,
    G_+^2 v_3 = 3 v_3.

Their exact overlaps with the source-plane code are nonzero. All identities and overlaps are checked in integer or Q(sqrt(5)) arithmetic. The vectors were first located by a numerical spectral probe, then reduced to these exact witnesses; the proof does not depend on numerical eigenvalues or a tolerance-based rank claim. Native covariance transports and verifies the witnesses for all six settings.

The spectral projectors of G_+ commute with N_i. Their pullbacks to the irreducible plane code are therefore nonnegative scalars times Q_i. A nonzero overlap proves a strictly positive scalar. Hence EVERY nonzero plane input has spectral support at 2 and -3.

For the third witness, the eigenvectors

    (G_+ + sqrt(3) I) v_3,
    (G_+ - sqrt(3) I) v_3

belong to eigenvalues +sqrt(3) and -sqrt(3), respectively. Their source overlaps cannot vanish: the relevant coefficients lie in Q(sqrt(5)), and sqrt(3) is not in that field. Again irreducibility makes both supported eigenvalues present for every nonzero plane input.

Thus every such input has at least the spectral support

    {2, -3, sqrt(3), -sqrt(3)}.

If it returned to its own ray under exp(-i*t*G_+), equal spectral phases would require

    5t = 2*pi*m,
    (sqrt(3)-2)t = 2*pi*n

for integers m,n. The ratio (sqrt(3)-2)/5 is irrational, so t=0 is the only solution.

An exact controlled pointer write with restored source would require precisely such a revival in the pointer-even block: |0> and |1> both have the same pointer-even component. Therefore

    no nonzero constant unweighted adjacency pulse implements the exact
    source-restoring nondemolition target on the original code.

This is an all-duration obstruction, not the absence of a good pulse in a scan. It does not exclude approximate readout, non-nondemolition instruments, piecewise-controlled generators, changed encodings, or a different dynamical law. No corresponding all-duration theorem is claimed for the Laplacian control.

## 8. The graph still does not choose the dynamical law

The Laplacian comparison uses the same contact graph, source, pointer, reference patterns, and fixed pulse list. It also gives a normalized instrument and the same exact analyzer partition, but different response functions. At t=2 its pointer-1 values are approximately 0.6391747926 and 0.6872844739 on axis and plane.

No pulse was chosen by optimizing discrimination or a Bell score. The list is fixed in the verifier: 0, 0.1, 0.25, 0.5, 1, 2, 3, 4. Both candidate generators have a mathematical unitary completion; selecting one as the physical law requires additional evidence.

The actual progress is therefore:

    native contact construction
      -> explicit coherent-model hypothesis
      -> normalized post-interaction maps
      -> exact axis/plane pointer effects
      -> precise constant-pulse ideal-instrument obstruction.

Normalization is now handled by an explicit law, rather than hidden in a fitted scale. Source-native selection of that law and autonomous completion remain open.

## 9. Reproduction

Run `python3 verify.py` with Python 3.10+, NumPy and SciPy. It replays the upstream archive, performs exact checks, and writes the numerical diagnostics separately. `--skip-upstream-replay` is a development option; the report records that omission explicitly. The delivered result uses the default full replay.

- REPORT.json: scope, exact findings, check totals, numerical tolerance.
- CHECKS.json: complete Boolean check ledger.
- EXACT_SYMMETRY.json: character sums and source decomposition.
- EXACT_SHORT_PULSE.json: exact expansion coefficients for all settings.
- EXACT_NO_REVIVAL_WITNESSES.json: transported witness overlaps and polynomials.
- inputs/witness_*.json: sparse exact spectral witnesses.
- NUMERICAL_PULSES.json: conditional responses, all outputs retained.
- SOURCE_RECEIPTS.json: hash of the unchanged upstream archive.
- REPLAY_CHECK.json: repeat-run comparison in this environment.

A tolerance of 5e-11 is used ONLY for numerical exponential/orthogonality diagnostics. Structural theorems and the no-revival claim use exact arithmetic plus the displayed proofs.

## External context

The coherent graph-walk convention is standard; it is not a new derivation of dynamics. R. Alvir et al., *Perfect State Transfer in Laplacian Quantum Walk*, arXiv:1409.5840, explicitly defines U(t)=exp(-itM) for a graph-related symmetric matrix and distinguishes generator choices. Mathematical instruments and unitary dilations are treated in John Watrous, *The Theory of Quantum Information*, Chapter 2. These references describe the added framework, not independent evidence for a physical Thalean realization.

**Keeper:** A coherent law makes the return normalized. It does not automatically make the apparatus finish the intended measurement.
